/* 
* var-> 변수 재선언 가능
* let, const-> 변수 재선언 불가능
* let-> 변수에 재할당 가능
* const->변수 재선언, 재할당 모두 불가능
*/
const scene = new THREE.Scene();  //  화면에 그리고자 하는 장면

init(); //renderer, 카메라, 움직임설정
directionalLight(); //빛 생성
loadObjLoader(); //객체 생성

function init() {
    // 브라우저가 WebGL을 지원하는지 체크
    if (WEBGL.isWebGLAvailable()) {                            
        const renderer = new THREE.WebGLRenderer({          // WebGL 렌더러 객체 생성
        antialias: true                                 
        });

        renderer.setSize(1024, 512);                        // 렌더링 할 화면 설정
        document.body.appendChild(renderer.domElement);     // 렌더러가 그릴 곳을 자식으로 추가

        perspectiveCamera()                                 // perspectiveCamera() 호출


        /*
        * 움직임: Orbit Controls,rotation
        * 궤도 컨트롤 객체를 이용하면 카메라가 강아지 객체 주위를 공전할 수 있고, 
        */
        controls = new THREE.OrbitControls(camera,renderer.domElement);  // 궤도컨트롤 객체 추가 
        controls.addEventListener('change',renderer.render);             // 이벤트 리스너 
        controls.rotateSpeed = 0.5;     // 회전 속도 설정 (디폴트: 1)
        controls.zoomSpeed = 1.0;       // ZOOM 속도 설정 (디폴트: 1)
        controls.minDistance = 10;      
        controls.maxDistance = 100;     // 줌 인/아웃 최소 거리, 최대 거리 지정
        controls.autoRotate = true;     // 기본적으로 강아지 객체가 자동 회전하게 합니다.
        controls.autoRotateSpeed = 3.0; // 자동 회전 속도

        /*
        * 애니메이션을 위한 렌더 루프, 객체를 동적으로 업데이트
        */
        function animate() {                
            requestAnimationFrame(animate);  // 반복
            controls.update();               // 객체를 동적으로 업데이트
            renderer.render(scene, camera);  // 화면,카메라 추가해서 렌더링
        }
        animate();
    }
    else {
        console.log('해당 브라우저가 WebGL을 지원하지 않습니다.'); // 브라우저가 WebGL을 지원X
    }
}


/*
* 카메라 객체 생성 함수
*/
function perspectiveCamera() {
    camera = new THREE.PerspectiveCamera(45, 1024 / 512, 1, 1000); // (카메라 절두체 수직 시야, 카메라 절투체 종횡비, plane 근처 카메라 절두체, 카메라 절두 원거리 평면)
    camera.position.x = 100;  // 카메라 객체 위치 지정 
    camera.position.y = -100;
    camera.position.z = 100;
    }


/*
* 빛 생성 함수
* 강아지 객체를 감싸는 cube가 있다 가정, 4개의 꼭지점에 위치에 light 객체 생성 
*/
function directionalLight() { // 공간에 빛을 추가하는 함수
let light = new THREE.DirectionalLight(0xffffff, 1);   // light 객체 생성, 첫 번째 매개변수로 '색', 두 번째 매개변수로 '강도' 지정
light.castShadow = false;                              // true로 설정하면 동적 그림자 투사
light.position.x = 5;                                  // 빛의 방출 시작 위치 지정
light.position.y = 5;                                 
light.position.z = 5;
scene.add(light);                                     

// 2번 light
let light2 = new THREE.DirectionalLight(0xffffff, 1);
 light.castShadow = false;
  light2.position.x = -5;      
light2.position.y = -5;
light2.position.z = -5;
scene.add(light2);

// 3번 light
let light4 = new THREE.DirectionalLight(0xffffff, 1);
    light.castShadow = false;
light4.position.x = 5;     
light4.position.y = -5;
light4.position.z = -5;
scene.add(light4);

// 4번 light
let light3 = new THREE.DirectionalLight(0xffffff, 1);
light3.castShadow = false;  
    light3.position.x = -5;       
light3.position.y = 5;
light3.position.z = 5;
scene.add(light3);
}



/*
    dog.obj 3D파일 로드, with texture(fur.png)
*/

var dog=new Object(); //새로운 객체 생성

var texture=new THREE.TextureLoader().load('fur.png');//텍스쳐 생성

function loadObjLoader() {
    const loader = new THREE.OBJLoader();
    loader.load(
        './dog1.obj',
        function (object) {
            dog.object = object; //dog 객체에 해당 object삽입
            var material=new THREE.MeshPhysicalMaterial( //physical material로 mesh생성
                {
                    map: texture    //texture mapping
                });
            object.traverse(function(child) {
            if(child instanceof THREE.Mesh) {
                child.material = material; //child mesh에 material삽입
            }
        }
    );
    scene.add(object);  // 강아지 객체 장면에 추가
}, function (xhr) {     // 로딩이 진행될 때 콘솔에 출력 
    console.log(xhr.loaded / xhr.total * 100, '% loaded');  
}, function (error) {   // 에러 발생 시 호출 
    alert('에러 발생');
});
}